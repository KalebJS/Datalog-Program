//
// Created by Kaleb Smith on 9/28/21.
//

#ifndef PARAMETER_H
#define PARAMETER_H

#include <string>

class Parameter {
private:

public:
    std::string toString ();


};


#endif //PARAMETER_H
